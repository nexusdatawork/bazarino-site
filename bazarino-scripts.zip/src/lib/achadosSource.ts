import raw from "@/data/achados-editions.json";
import type { AchadosEdition, AchadoItem } from "@/data/achadosEditions";

const editions = raw as AchadosEdition[];

function sortDescByDate(a: AchadosEdition, b: AchadosEdition) {
  return new Date(b.date).getTime() - new Date(a.date).getTime();
}

export function listDailyEditions(): AchadosEdition[] {
  return editions.filter((e) => e.type === "daily").sort(sortDescByDate);
}

export function listCategoryEditions(category: string): AchadosEdition[] {
  return editions
    .filter((e) => e.type === "category" && e.category === category)
    .sort(sortDescByDate);
}

export function getDailyEditionByDate(date: string): AchadosEdition | undefined {
  return editions.find((e) => e.type === "daily" && e.date === date);
}

export function getCategoryEditionByDate(date: string, category: string): AchadosEdition | undefined {
  return editions.find((e) => e.type === "category" && e.date === date && e.category === category);
}

export function listAvailableDates(): string[] {
  const dates = new Set(editions.filter((e) => e.type === "daily").map((e) => e.date));
  return [...dates].sort((a, b) => new Date(b).getTime() - new Date(a).getTime());
}

export function listAllCategories(): string[] {
  const set = new Set<string>();

  for (const ed of editions) {
    for (const item of ed.items as any[]) {
      const cat = typeof item.category === "string" ? item.category.trim() : "";
      if (cat) set.add(cat);
    }
  }

  return [...set].sort();
}


export function listCategoriesByFrequency(limit = 12): { slug: string; count: number }[] {
  const counts = new Map<string, number>();
  for (const ed of editions) {
    for (const item of ed.items) {
      counts.set(item.category, (counts.get(item.category) ?? 0) + 1);
    }
  }
  return [...counts.entries()]
    .map(([slug, count]) => ({ slug, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, limit);
}

export function titleFromSlug(slug: string) {
  return slug
    .split("-")
    .map(s => s.charAt(0).toUpperCase() + s.slice(1))
    .join(" ");
}

// src/lib/achadosSource.ts

/**
 * Lista todas as combinações (data + categoria) que EXISTEM no JSON.
 * Isso elimina o cross-product com categorias estáticas.
 */
export function listCategoryDayRoutes(): { date: string; category: string }[] {
  return editions
    .filter((e) => e.type === "category" && !!e.category)
    .map((e) => ({ date: e.date, category: e.category! }));
}

/**
 * Retorna as categorias publicadas em um dia específico (somente se existir edição de categoria naquele dia).
 * Útil para navegação interna do dia.
 */
export function listCategoriesForDate(date: string): string[] {
  const set = new Set<string>();
  for (const e of editions) {
    if (e.type === "category" && e.date === date && e.category) set.add(e.category);
  }
  return [...set].sort();
}



