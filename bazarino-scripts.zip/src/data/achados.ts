// src/data/achados.ts
import editions from "./achados-editions.json";

export type Achado = {
  id: string;
  title: string;
  category: string;
  store: string;
  price: number;
  oldPrice?: number | null;
  image?: string | null;
  href: string;
  score?: number | null;
  date?: string | null;
  reason?: string | null;
};


/* ------------------------
   Utils
------------------------ */

function normalizeImg(src?: unknown): string | null {
  if (typeof src !== "string") return null;
  const s = src.trim();
  if (!s) return null;
  if (s.startsWith("http://") || s.startsWith("https://")) return s;
  if (s.startsWith("/")) return s;
  if (s.startsWith("./")) return "/" + s.slice(2);
  return "/" + s;
}

/* ------------------------
   Flatten das edições
------------------------ */

function extractItems(): Achado[] {
  const result: Achado[] = [];

  for (const edition of editions as any[]) {
    if (!Array.isArray(edition.items)) continue;

    for (const item of edition.items) {
      if (!item || !item.price) continue;

      result.push({
        id: String(item.id),
        title: String(item.name ?? item.title ?? "Oferta"),
        category: String(item.category ?? "geral"),
        store: String(item.vendor ?? ""),
        price: Number(item.price),
        oldPrice:
          item.oldPrice !== undefined && item.oldPrice !== null
            ? Number(item.oldPrice)
            : null,
        image: normalizeImg(item.image),
        href: String(item.affiliateUrl ?? item.href ?? "#"),
        score:
          item.score !== undefined && item.score !== null
            ? Number(item.score)
            : null,
        date: edition.date ?? null,
        reason: item.reason ?? null,
      });
    }
  }

  return result;
}

export const achados: Achado[] = extractItems();

/* ------------------------
   API usada pelo site
------------------------ */

export function getLatestAchados(limit = 6): Achado[] {
  return [...achados]
    .sort((a, b) => {
      const da = a.date ? new Date(a.date).getTime() : 0;
      const db = b.date ? new Date(b.date).getTime() : 0;
      return db - da;
    })
    .slice(0, limit);
}

export function getAchadosByCategory(category: string, limit?: number): Achado[] {
  const filtered = achados.filter((a) => a.category === category);
  return typeof limit === "number" ? filtered.slice(0, limit) : filtered;
}
