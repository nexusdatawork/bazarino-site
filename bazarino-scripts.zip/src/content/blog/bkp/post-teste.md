---
title: "Post teste do Blog"
description: "Um post simples para validar o pipeline do blog."
pubDate: "2025-12-19"
tags: ["teste", "blog"]
author: "O Bazarino"
draft: false
canonical: "https://obazarino.com.br/blog/post-teste/"
---

## Funcionou 🎯

Se você está vendo isso em `/blog/post-teste/`, então o blog está pronto para o n8n gerar posts.
